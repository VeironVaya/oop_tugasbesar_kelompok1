import React from "react";
import LatestCollection from "../components/LatestCollection";

const Home = () => {
  return (
    <div>
      <LatestCollection />
    </div>
  );
};

export default Home;
